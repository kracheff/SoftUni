#!/bin/bash

cd bin
jar -cf ../softuni.jar .

