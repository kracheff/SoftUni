#!/bin/bash

java -classpath softuni.jar;lib/lanterna-2.1.7.jar org.softuni.main.Main
