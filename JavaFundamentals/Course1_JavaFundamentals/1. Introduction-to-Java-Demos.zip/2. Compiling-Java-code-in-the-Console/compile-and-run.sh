#!/bin/bash

javac HelloJava.java

ls -al

java HelloJava
