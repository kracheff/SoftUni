/**
 * Created by user on 18.03.2016.
 */
public class AssignVariables {
    public static void main(String[] args) {
        boolean bool = false;
        String address = "Palo Alto, CA";
        short shortMax = 32767;
        int twoMlrd = 2000000000;
        double longNumber = 0.1234567891011;
        float shortNumber = 0.5F;
        long biggestNumber = 919827112351L;
        byte smallInteger = 127;
        char charC = 'c';
    }
}
